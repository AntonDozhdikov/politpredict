# BRICS–PolSys MARL v10.0: результаты

Контрфактический политологический многоагентный эксперимент; не прогноз и не рейтинг государств.

## Порядок чтения
1. `excel/01_Overview.xlsx` — дизайн, gate, endpoint, потери, P1–P5 и E1–E12.
2. `excel/02_Inference_Units.xlsx` — seed×scenario, censored recovery и распределительные потери.
3. `excel/03_Mechanisms_Compact.xlsx` — механизм-единицы и диагностика весов.
4. `excel/04_Mechanism_Audit.xlsx` — точные строки E1–E12.
5. `excel/05_PolSys.xlsx` — диагностические компоненты и dominance.
6. `excel/06_Figure_Data.xlsx` — точные источники восьми графиков.

Primary: Holm. Exploratory: BH-FDR. Независимая единица — seed.
World dynamics: country_gated_dnlssm. Outer observed test 2021–2025 не использован при gate.
Профиль: STANDARD. Сиды: 17, 42, 101, 202, 303, 404, 505, 606, 707, 808. Горизонт: 40.
