# Содержание архива

- `excel/` — шесть проверенных книг;
- `figures/` — восемь PNG/SVG;
- `data/` — компактные Parquet;
- `guides/` — правила чтения;
- `artifact_manifest.json` — SHA-256 и размеры.

Checkpoints, optimizers и cache исключены.
